self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "24a60f5f8d44a69e67ce",
    "url": "css/app.3f25f0c2.css"
  },
  {
    "revision": "33d12a78ab71406c1b57",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "c7bd22b0c1899005aff302e647d5ca09",
    "url": "index.html"
  },
  {
    "revision": "8ab5fc87bd2501fbcc8def2d8ed26c44",
    "url": "js/0.a6e1f3a4.worker.js"
  },
  {
    "revision": "24a60f5f8d44a69e67ce",
    "url": "js/app.c22deb58.js"
  },
  {
    "revision": "33d12a78ab71406c1b57",
    "url": "js/chunk-vendors.5db7ca01.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);